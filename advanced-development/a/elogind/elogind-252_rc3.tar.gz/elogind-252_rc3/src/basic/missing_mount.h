/* SPDX-License-Identifier: LGPL-2.1-or-later */
#pragma once

#include <sys/mount.h>

/* dab741e0e02bd3c4f5e2e97be74b39df2523fc6e (5.10) */
#ifndef MS_NOSYMFOLLOW
#define MS_NOSYMFOLLOW 256
#endif
