**ddcutil** Internal Documentation

