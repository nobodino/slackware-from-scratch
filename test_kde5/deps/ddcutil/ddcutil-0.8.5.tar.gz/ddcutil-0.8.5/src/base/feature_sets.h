/* feature_sets.h
 *
 * <copyright>
 * Copyright (C) 2014-2017 Sanford Rockowitz <rockowitz@minsoft.com>
 *
 * Licensed under the GNU General Public License Version 2
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 * </endcopyright>
 */

/** \file
 *
 */

#ifndef FEATURE_SETS_H_
#define FEATURE_SETS_H_

/** \cond */
#include <stdbool.h>
/** \endcond */

#include "util/coredefs.h"

// so all references still work with version spec declarations moved to vcp_version_spec.h
#include "base/vcp_version.h"



// If this enum is changed, be sure to change the corresponding
// table in vcp_feature_base.c
typedef enum {
   VCP_SUBSET_PROFILE         = 0x8000,
   VCP_SUBSET_COLOR           = 0x4000,
   VCP_SUBSET_LUT             = 0x2000,
   VCP_SUBSET_CRT             = 0x1000,
   VCP_SUBSET_TV              = 0x0800,
   VCP_SUBSET_AUDIO           = 0x0400,
   VCP_SUBSET_WINDOW          = 0x0200,
   VCP_SUBSET_DPVL            = 0x0100,

   // subsets used only on commands processing,
   // not in feature descriptor table
   VCP_SUBSET_SCAN            = 0x0080,
   VCP_SUBSET_ALL             = 0x0040,
   VCP_SUBSET_SUPPORTED       = 0x0020,
   VCP_SUBSET_KNOWN           = 0x0010,
   VCP_SUBSET_PRESET          = 0x0008,    // uses VCP_SPEC_PRESET
   VCP_SUBSET_MFG             = 0x0004,    // mfg specific codes
   VCP_SUBSET_TABLE           = 0x0002,    // is a table feature
   VCP_SUBSET_SINGLE_FEATURE  = 0x0001,
   VCP_SUBSET_NONE            = 0x0000,
} VCP_Feature_Subset;


typedef
struct _Vcp_Subset_Desc {
   VCP_Feature_Subset     subset_id;
   char *                 subset_id_name;
   char *                 public_name;
} Vcp_Subset_Desc;


extern struct _Vcp_Subset_Desc vcp_subset_desc[];
const int vcp_subset_count;

char * feature_subset_name(VCP_Feature_Subset subset_id);


typedef struct {
   VCP_Feature_Subset  subset;
   Byte                specific_feature;
} Feature_Set_Ref;

void report_feature_set_ref(Feature_Set_Ref * fsref, int depth);


#endif /* FEATURE_SETS_H_ */
