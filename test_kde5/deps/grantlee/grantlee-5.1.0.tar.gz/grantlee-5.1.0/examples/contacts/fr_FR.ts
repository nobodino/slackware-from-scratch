<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>GR_FILENAME</name>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="1"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="10"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="11"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="12"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="13"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="36"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="37"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="38"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="39"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="40"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="68"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="69"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="70"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="71"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="72"/>
        <source>Nickname</source>
        <translation>surnom</translation>
    </message>
    <message numerus="yes">
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="2"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="14"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="41"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="73"/>
        <source>%n person</source>
        <comment>The total number of people displayed</comment>
        <translation>
            <numerusform>%n personne</numerusform>
            <numerusform>%n personnes</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="3"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="15"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="23"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="42"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="50"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="74"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="82"/>
        <source>Name</source>
        <comment>The name of a person</comment>
        <translation>nom</translation>
    </message>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="4"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="16"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="24"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="25"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="26"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="43"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="51"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="52"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="53"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="65"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="75"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="83"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="84"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="85"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="97"/>
        <source>Email</source>
        <translation>émail</translation>
    </message>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="5"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="17"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="27"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="28"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="29"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="44"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="54"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="55"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="56"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="66"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="76"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="86"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="87"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="88"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="98"/>
        <source>Phone</source>
        <translation>téléphone</translation>
    </message>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="6"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="18"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="30"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="31"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="32"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="45"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="57"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="58"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="59"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="67"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="77"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="89"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="90"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="91"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="99"/>
        <source>Address</source>
        <translation>adresse</translation>
    </message>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="7"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="19"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="33"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="34"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="35"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="46"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="60"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="61"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="62"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="78"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="92"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="93"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="94"/>
        <source>Birthday</source>
        <translation>anniversaire</translation>
    </message>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="8"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="20"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="47"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="79"/>
        <source>Salary</source>
        <translation>salaire</translation>
    </message>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="9"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="21"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="48"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="80"/>
        <source>Rating</source>
        <translation>évaluation</translation>
    </message>
    <message numerus="yes">
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="22"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="49"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="63"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="81"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="95"/>
        <source>%n person</source>
        <translation>
            <numerusform>%n personne</numerusform>
            <numerusform>%n personnes</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="64"/>
        <location filename="../../../../../../build/qt47/playground/pim/grantlee/examples/contacts/output.cpp" line="96"/>
        <source>Name</source>
        <translation>nom</translation>
    </message>
</context>
</TS>
