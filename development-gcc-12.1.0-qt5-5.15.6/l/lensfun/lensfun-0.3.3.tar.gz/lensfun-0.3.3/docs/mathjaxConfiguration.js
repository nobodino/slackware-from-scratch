MathJax.Hub.Config({
    messageStyle: "none"
});
