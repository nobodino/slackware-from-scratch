---
title: New release is on its way!
layout: default
category: news
---

We promised to release new versions at least every 6 months but the next release has to be postponed by a few weeks till the end of january. The reason is that some severe bugs were discovered and although there are already patches in the bug tracker, some further checks are necessary. We want to be sure everything is fine and no new bugs are introduced by the changes.

The good news is that over the last few months the interest in Lensfun did grow and many people send in calibration data for quite a lot of lenses and camera updates. Stay tuned! 
