#!/bin/sh
# Set more relaxed (glibc-2.3.5 like) malloc() checking.
#
# This relaxes the default paranoia level so that it reports
# bugs, but does not kill the questionable process.  You can
# get away with running broken programs with this setting,
# but at a possible performance and security cost.
#export MALLOC_CHECK_=1
