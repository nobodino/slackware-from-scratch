#!/bin/sh
libtoolize
aclocal
autoconf
automake --add-missing
