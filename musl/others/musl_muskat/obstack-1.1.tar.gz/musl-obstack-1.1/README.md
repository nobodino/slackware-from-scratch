### musl-obstack

The musl-obstack package is a copy + paste of the `obstack`
functions and macros found in GNU gcc `libiberty` library
for use with musl libc.
